function Footer() {
  return (
    <div className="footer">
      <div className="footer-item">
        <span className="gradient">

         
        </span>
      </div>
    </div>
  );
}

export default Footer;
